﻿using System;
using System.Threading.Tasks;

namespace mimd
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] data = { 1, 2, 3, 4, 5 };
            int[] resultSquare = new int[data.Length];
            int[] resultMultiply = new int[data.Length];


            Task taskSquare = Task.Run(() =>
            {
                for (int i = 0; i < data.Length; i++)
                {
                    resultSquare[i] = data[i] * data[i];
                }
            });

            Task taskMultiply = Task.Run(() =>
            {
                for (int i = 0; i < data.Length; i++)
                {
                    resultMultiply[i] = data[i] * 10;
                }
            });

            Task.WaitAll(taskSquare, taskMultiply);

            Console.WriteLine("Elevar al cuadrado: " + string.Join(", ", resultSquare));
            Console.WriteLine("Multiplicar por 10: " + string.Join(", ", resultMultiply));
            Console.ReadKey();
        }
    }
}
